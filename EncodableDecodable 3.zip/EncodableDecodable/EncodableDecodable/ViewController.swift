//
//  ViewController.swift
//  EncodableDecodable
//
//  Created by Nadaf on 01/02/19.
//  Copyright © 2019 Nadaf. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    @IBAction func postTap(_ sender: Any) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return  }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
      
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let newPost = Post.init(body: "This is the post of the body", id: 123, title: "iOS Development", userId: 111)
        
        do {
          let jsonBody = try JSONEncoder().encode(newPost)
            
            request.httpBody = jsonBody
            
            
        } catch  {
            
        }
        
         let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, _, _) in
            guard let data = data else { return }
            
            
            do{
//                let json = try  JSONSerialization.jsonObject(with: data, options: [])
//                print(json)
                
                
                let sentPost = try JSONDecoder().decode(Post.self, from: data)
                print(sentPost)
                
                
            }catch{
                
            }
        }
        
        
        task.resume()
    }
    
    @IBAction func getTap(_ sender: Any) {
        
    }
}

