//
//  Users.swift
//  EncodableDecodable
//
//  Created by Nadaf on 03/02/19.
//  Copyright © 2019 Nadaf. All rights reserved.
//

import Foundation


struct Users : Decodable{
    
    let company : [String : String]
    let email : String
    let id : Int
    let name : String
    let phone : String
    let username : String
    let website : String
    
    
    
    
    
    
    
    
    
}
