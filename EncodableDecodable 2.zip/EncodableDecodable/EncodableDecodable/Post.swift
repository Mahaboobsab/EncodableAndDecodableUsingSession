//
//  Post.swift
//  EncodableDecodable
//
//  Created by Nadaf on 02/02/19.
//  Copyright © 2019 Nadaf. All rights reserved.
//

import Foundation


struct Post : Encodable {
    
    
    let body: String
    let id : Int
    let title : String
    let userId : Int
    
    
    
    
}
